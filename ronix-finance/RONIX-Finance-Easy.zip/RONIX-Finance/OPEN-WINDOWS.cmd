@echo off
start "" "%~dp0RONIX-Finance.html"
